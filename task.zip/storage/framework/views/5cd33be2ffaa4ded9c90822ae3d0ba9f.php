<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home2/fastbtce/dasboard.wpalleviate.com/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>