<?php echo e($slot); ?>

<?php /**PATH /home2/fastbtce/dasboard.wpalleviate.com/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>