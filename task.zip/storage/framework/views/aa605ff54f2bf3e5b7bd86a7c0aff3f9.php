<?php $__env->startSection('title'); ?>
<?= get_label('Plan_Requests', 'Plan Requests') ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between m-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/home')); ?>"><?= get_label('home', 'Home') ?></a>
                    </li>
                    <li class="breadcrumb-item active">
                        <?= get_label('Plan Requests', 'Plan Requests') ?>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <span data-bs-toggle="modal" data-bs-target="#create_todo_modal"><a href="javascript:void(0);" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?= get_label('create_todo', 'Create todo') ?>"><i class='bx bx-plus'></i></a></span>
        </div>
    </div>

    <?php if(is_countable($planRequests) && count($planRequests) > 0): ?>
    <div class="card mt-4">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th><?= get_label('id', 'Id') ?></th>
                        <th><?= get_label('Plan Info', 'Plan Info') ?></th>
                        <th><?= get_label('Client Info', 'Client info') ?></th>
                        <th><?= get_label('Approved or not', 'Approved or not') ?></th>
                        <th><?= get_label('actions', 'Actions') ?></th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $planRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <span class="mx-4">
                                    <p class="m-0"><?php echo e($request->id); ?></p>
                                    <h7 class="m-0 text-muted"><?php echo e(format_date($request->created_at,'H:i:s')); ?></h7>

                                </span>
                            </div>
                        </td>
                        <td style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            Plan Name: <?php echo e($request->plan->name); ?> <br>
                            Plan Amount: <?php echo e($request->plan->amount); ?> $ <br>
                            Plan Duration: <?php echo e($request->plan->duration); ?> days <br>
                            Plan Projects: <?php echo e($request->plan->projects); ?> <br>
                            Plan Tasks per Project: <?php echo e($request->plan->tasks_per_project); ?>

                        </td>
                        <td style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            Client Name: <a href="/clients/profile/<?php echo e($request->client->id); ?>"><?php echo e($request->client->first_name . ' ' . $request->client->last_name); ?></a> <br>
                            Client Email: <?php echo e($request->client->email); ?>

                        </td>
                        
                        
                        <td>
                            
                            <?php if($request->is_approved): ?>
                            <span class="badge bg-success">Approved</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Not Approved</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex">
                                
                                <?php if($request->is_approved == 0): ?>
                                <button type="button" class="btn btn-success approved-plan" data-plan-id="<?php echo e($request->id); ?>">Approved</button>
                                <?php endif; ?>
                                <form action="<?php echo e(route('plans.approve', $request->id)); ?>" method="post" class="d-none" id="approve-plan-form-<?php echo e($request->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                </form>

                                <button type="button" class="btn delete-plan" data-plan-id="<?php echo e($request->id); ?>"><i class='bx bx-trash text-danger mx-1'></i></button>
                                <form action="<?php echo e(route('plans.reject', $request->id)); ?>" method="post" class="d-none" id="delete-plan-form-<?php echo e($request->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
            </table>
        <div class="p-3">
            <?php echo e($planRequests->links()); ?>

        </div>

        </div>
    </div>

    <?php else: ?>
    <p>No  plan requests found.</p>
    <?php endif; ?>
</div>


<div class="modal fade" id="deletePlanModalReq" tabindex="-1" aria-labelledby="deletePlanModalReqLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deletePlanModalReqLabel"><?php echo e(__('Confirm Deletion')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e(__('Are you sure you want to delete this plan reuqest.')); ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                <button type="button" class="btn btn-danger confirm-delete"><?php echo e(__('Delete')); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="approvedPlanModalReq" tabindex="-1" aria-labelledby="approvedPlanModalReqLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="approvedPlanModalReqLabel"><?php echo e(__('Confirm Assign Plan')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e(__('Are you sure you want to assign this plan to this client.')); ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                <button type="button" class="btn btn-success confirm-approved"><?php echo e(__('Approved')); ?></button>
            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const deleteButtons = document.querySelectorAll('.delete-plan');
        const modal = new bootstrap.Modal(document.getElementById('deletePlanModalReq'));

        deleteButtons.forEach(button => {
            button.addEventListener('click', function () {
                const planId = this.getAttribute('data-plan-id');
                const form = document.getElementById('delete-plan-form-' + planId);

                modal.show();

                document.querySelector('.confirm-delete').addEventListener('click', function () {
                    form.submit();
                });
            });
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
        const approvedButtons = document.querySelectorAll('.approved-plan');
        const modalApproved = new bootstrap.Modal(document.getElementById('approvedPlanModalReq'));

        approvedButtons.forEach(button => {
            button.addEventListener('click', function () {
                const planId = this.getAttribute('data-plan-id');
                const form = document.getElementById('approve-plan-form-' + planId);

                modalApproved.show();

                document.querySelector('.confirm-approved').addEventListener('click', function () {
                    form.submit();
                });
            });
        });
    });

    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dashboard.wpalleviate.com/resources/views/plans/admin_requests.blade.php ENDPATH**/ ?>