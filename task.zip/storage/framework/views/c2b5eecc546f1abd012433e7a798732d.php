<?php $__env->startSection('title'); ?>
    <?php echo e(__('Plans')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <?php if(session('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
                
                <div class="mt-4 float-end">
                    <a href="<?php echo e(route('plans.create')); ?>" class="btn btn-success"><?php echo e(__('Create Plan')); ?></a>
                </div>
                <div class="container">
                    <div class="row mt-5 justify-content-center">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-3">
                                <div class="card">
                                    <div class="card-header"><h4> <?php echo e($plan->name); ?></h4></div>
                                    <div class="card-body">
                                        <p class="card-text">Projects Allowed: <?php echo e($plan->projects); ?></p>
                                        <p class="card-text">Tasks per Project: <?php echo e($plan->tasks_per_project); ?></p>
                                        <p class="card-text">Price: <?php echo e($plan->amount); ?> $</p>
                                        <p class="card-text">Duration: <?php echo e($plan->duration); ?> (IN Days)</p>

                                        <a href="<?php echo e(route('plans.edit', $plan->id)); ?>" class="btn btn-secondary"><?php echo e(__('Edit')); ?></a>
                                        <button type="button" class="btn btn-danger delete-plan" data-plan-id="<?php echo e($plan->id); ?>"><?php echo e(__('Delete')); ?></button>
                                        <form action="<?php echo e(route('plans.destroy', $plan->id)); ?>" method="post" class="d-none" id="delete-plan-form-<?php echo e($plan->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

   <!-- Modal -->
   <div class="modal fade" id="deletePlanModal" tabindex="-1" aria-labelledby="deletePlanModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deletePlanModalLabel"><?php echo e(__('Confirm Deletion')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e(__('Are you sure you want to delete this plan? Its also delete plan subscrption of clients.')); ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                <button type="button" class="btn btn-danger confirm-delete"><?php echo e(__('Delete')); ?></button>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const deleteButtons = document.querySelectorAll('.delete-plan');
        const modal = new bootstrap.Modal(document.getElementById('deletePlanModal'));

        deleteButtons.forEach(button => {
            button.addEventListener('click', function () {
                const planId = this.getAttribute('data-plan-id');
                const form = document.getElementById('delete-plan-form-' + planId);

                modal.show();

                document.querySelector('.confirm-delete').addEventListener('click', function () {
                    form.submit();
                });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dashboard.wpalleviate.com/resources/views/plans/admin_index.blade.php ENDPATH**/ ?>