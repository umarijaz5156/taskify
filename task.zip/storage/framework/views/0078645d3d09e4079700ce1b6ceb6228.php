

<?php $__env->startSection('title'); ?>
<?= get_label('permission_settings', 'Permission settings') ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="d-flex justify-content-between m-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/home')); ?>"><?= get_label('home', 'Home') ?></a>
                    </li>
                    <li class="breadcrumb-item">
                        <?= get_label('settings', 'Settings') ?>
                    </li>
                    <li class="breadcrumb-item active">
                        <?= get_label('permissions', 'Permissions') ?>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="<?php echo e(url('/roles/create')); ?>"><button type="button" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?= get_label('create_role', 'Create role') ?>"><i class='bx bx-plus'></i></button></a>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?= get_label('role', 'Role') ?></th>
                            <th><?= get_label('permissions', 'Permissions') ?></th>
                            <th><?= get_label('actions', 'Actions') ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <h4 class="text-capitalize fw-bold mb-0"><?php echo e($role->name); ?></h4>
                            </td>

                            <?php if($role->name == 'admin'): ?>
                            <td>
                                <span class="badge bg-success"><?= get_label('admin_has_all_permissions', 'Admin has all the permissions') ?></span>
                            </td>
                            <td>-</td> <!-- Display dash for actions -->
                            <?php else: ?>
                            <?php $permissions = $role->permissions; ?>
                            <?php if(count($permissions) != 0): ?>
                            <td style="display: flex; flex-wrap: wrap;">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge rounded p-2 m-1 px-3 bg-primary">
                                    <?php echo e($role->hasPermissionTo($permission) ? str_replace("_", " ", $permission->name) : ''); ?>

                                </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <?php else: ?>
                            <td class="align-items-center">
                                <span>
                                    <?= get_label('no_permissions_assigned', 'No Permissions Assigned!') ?>
                                </span>
                            </td>
                            <?php endif; ?>
                            <td class="align-items-center">
                                <div class="d-flex">
                                    <a href="/roles/edit/<?php echo e($role->id); ?>" class="card-link"><i class='bx bx-edit mx-1'></i></a>
                                    <a href="javascript:void(0);" type="button" data-id="<?php echo e($role->id); ?>" data-type="roles" class="card-link mx-4 delete"><i class='bx bx-trash text-danger mx-1'></i></a>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>


                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dasboard.wpalleviate.com/resources/views/settings/permission_settings.blade.php ENDPATH**/ ?>