<?php echo e($slot); ?>

<?php /**PATH /home2/fastbtce/dashboard.wpalleviate.com/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>