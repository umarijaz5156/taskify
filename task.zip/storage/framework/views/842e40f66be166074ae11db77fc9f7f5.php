

<?php $__env->startSection('title'); ?>
<?= get_label('todo_list', 'Todo list') ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between m-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/home')); ?>"><?= get_label('home', 'Home') ?></a>
                    </li>
                    <li class="breadcrumb-item active">
                        <?= get_label('todos', 'Todos') ?>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <span data-bs-toggle="modal" data-bs-target="#create_todo_modal"><a href="javascript:void(0);" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?= get_label('create_todo', 'Create todo') ?>"><i class='bx bx-plus'></i></a></span>
        </div>
    </div>

    <?php if(is_countable($todos) && count($todos) > 0): ?>
    <div class="card mt-4">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th><?= get_label('todo', 'Todo') ?></th>
                        <th><?= get_label('priority', 'Priority') ?></th>
                        <th><?= get_label('description', 'Description') ?></th>
                        <th><?= get_label('actions', 'Actions') ?></th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <div>
                                    <form method="POST" action="/todos/cross/<?php echo e($todo->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="checkbox" id="<?php echo e($todo->id); ?>" onclick='update_status(this)' name="<?php echo e($todo->id); ?>" class="form-check-input mt-0" <?php echo e($todo->is_completed ? 'checked' : ''); ?>>
                                    </form>
                                </div>
                                <span class="mx-4">
                                    <h4 class="m-0 <?= $todo->is_completed ? 'striked' : '' ?>" id="<?php echo e($todo->id); ?>_title"><?php echo e($todo->title); ?></h4>
                                    <h7 class="m-0 text-muted"><?php echo e(format_date($todo->created_at,'H:i:s')); ?></h7>

                                </span>
                            </div>
                        </td>
                        <td>
                            <span class='badge bg-label-<?php echo e(config("taskhub.priority_labels")[$todo->priority]); ?> me-1'><?php echo e($todo->priority); ?></span>
                        </td>
                        <td style="max-width: 100px; overflow: hidden; text-overflow: ellipsis; white-space:nowrap">
                            <?php echo e($todo->description); ?>

                        </td>
                        <td>
                            <div class="d-flex">
                                <a href="javascript:void(0);" class="edit-todo" data-bs-toggle="modal" data-bs-target="#edit_todo_modal" data-id="<?php echo e($todo->id); ?>" title="<?= get_label('update', 'Update') ?>" class="card-link"><i class='bx bx-edit mx-1'></i></a>


                                <a href="javascript:void(0);" type="button" data-id="<?php echo e($todo->id); ?>" data-type="todos" class="card-link mx-4 delete"><i class='bx bx-trash text-danger mx-1'></i></a>

                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>

    <?php else: ?>
    <?php
    $type = 'Todos'; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state-card','data' => ['type' => $type]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('empty-state-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($type)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php endif; ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dasboard.wpalleviate.com/resources/views/todos/list.blade.php ENDPATH**/ ?>