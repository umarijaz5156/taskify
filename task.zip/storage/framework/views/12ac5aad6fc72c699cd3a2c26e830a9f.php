<!-- tasks -->
<div class="<?= Request::segment(1) == 'home' ? '' : 'card ' ?>mt-4">
    <div class="table-responsive text-nowrap">
        <?php echo e($slot); ?>

        
        <?php if($tasks > 0): ?>

        <div class="row mt-4 mx-2">
            <div class="mb-3 col-md-3">
                <div class="input-group input-group-merge">
                    <input type="text" id="task_start_date_between" name="task_start_date_between" class="form-control" placeholder="<?= get_label('start_date_between', 'Start date between') ?>" autocomplete="off">
                </div>
            </div>
            <div class="mb-3 col-md-3">
                <div class="input-group input-group-merge">
                    <input type="text" id="task_end_date_between" name="task_end_date_between" class="form-control" placeholder="<?= get_label('end_date_between', 'End date between') ?>" autocomplete="off">
                </div>
            </div>
            <?php if(getAuthenticatedUser()->can('manage_projects')): ?>
            <div class="col-md-3">
                <select class="form-select" id="tasks_project_filter" aria-label="Default select example">
                    <option value=""><?= get_label('select_project', 'Select project') ?></option>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($proj->id); ?>" <?php if(request()->has('project') && request()->project == $proj->id): ?> selected <?php endif; ?>><?php echo e($proj->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            
            <?php endif; ?>
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
            <?php if(explode('_',$id)[0] !='client' && explode('_',$id)[0] !='user'): ?>
            <div class="col-md-3">
                <select class="form-select" id="tasks_user_filter" aria-label="Default select example">
                    <option value=""><?= get_label('select_user', 'Select user') ?></option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->first_name.' '.$user->last_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <select class="form-select" id="tasks_client_filter" aria-label="Default select example">
                    <option value=""><?= get_label('select_client', 'Select client') ?></option>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->first_name.' '.$client->last_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php endif; ?>
            <?php endif; ?>

            <div class="col-md-3">
                <select class="form-select" id="task_status_filter" aria-label="Default select example">
                    <option value=""><?= get_label('select_status', 'Select status') ?></option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $selected = (request()->has('status') && request()->status == $status->id) ? 'selected' : '';
                    ?>
                    <option value="<?php echo e($status->id); ?>" <?php echo e($selected); ?>><?php echo e($status->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


        </div>

        <input type="hidden" name="task_start_date_from" id="task_start_date_from">
        <input type="hidden" name="task_start_date_to" id="task_start_date_to">

        <input type="hidden" name="task_end_date_from" id="task_end_date_from">
        <input type="hidden" name="task_end_date_to" id="task_end_date_to">

        <input type="hidden" id="data_type" value="tasks">
        <input type="hidden" id="data_table" value="task_table">
        <div class="mx-2 mb-2">
            
            <table id="task_table" data-toggle="table" data-loading-template="loadingTemplate" data-url="/tasks/list/<?php echo e($id??''); ?>" data-icons-prefix="bx" data-icons="icons" data-show-refresh="true" data-total-field="total" data-trim-on-search="false" data-data-field="rows" data-page-list="[5, 10, 20, 50, 100, 200]" data-search="true" data-side-pagination="server" data-show-columns="true" data-pagination="true" data-sort-name="id" data-sort-order="desc" data-mobile-responsive="true" data-query-params="queryParamsTasks">
                <thead>
                    <tr>
                        <th data-checkbox="true"></th>
                        <th data-sortable="true" data-field="id"><?= get_label('id', 'ID') ?></th>
                        <th data-sortable="true" data-field="title"><?= get_label('task', 'Task') ?></th>
                        <th data-sortable="true" data-field="project_id"><?= get_label('project', 'Project') ?></th>
                        <th data-field="users" data-formatter="TaskUserFormatter"><?= get_label('Team Member', 'Team Member') ?></th>
                        <th data-field="clients" data-formatter="TaskClientFormatter"><?= get_label('clients', 'Clients') ?></th>
                        <!--<th data-sortable="true" data-field="start_date"><?= get_label('starts_at', 'Starts at') ?></th>-->
                        <!--<th data-sortable="true" data-field="end_date"><?= get_label('ends_at', 'Ends at') ?></th>-->
                        <!--<th data-sortable="true" data-field="task_department"><?= get_label('task_department', 'Task Department') ?></th>-->
                        <th data-sortable="true" data-field="status_id"><?= get_label('status', 'Status') ?></th>
                        <th data-formatter="actionFormatter"><?= get_label('actions', 'Actions') ?></th>
                    </tr>
                </thead>
            </table>
        </div>
        <?php else: ?>
        <?php
        $type = 'Tasks';
        $link = isset($id) && !empty($id) ? "projects/tasks/create/" . explode('_', $id)[1] : "";
        ?>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state-card','data' => ['type' => $type,'link' => $link]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('empty-state-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($type),'link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($link)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</div>


<script>
    var label_update = '<?= get_label('update', 'Update') ?>';
    var label_delete = '<?= get_label('delete', 'Delete') ?>';
    var label_duplicate = '<?= get_label('duplicate', 'Duplicate') ?>';
    var label_not_assigned = '<?= get_label('not_assigned', 'Not assigned') ?>';
    var add_favorite = '<?= get_label('add_favorite', 'Click to mark as favorite') ?>';
    var remove_favorite = '<?= get_label('remove_favorite', 'Click to remove from favorite') ?>';
    var id = '<?= $id ?>';
</script>
<script src="<?php echo e(asset('assets/js/pages/tasks.js')); ?>"></script><?php /**PATH /home2/fastbtce/dashboard.wpalleviate.com/resources/views/components/tasks-card.blade.php ENDPATH**/ ?>