<?php $__env->startSection('title'); ?>
    <?php echo e(__('Create Plan')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Update Plan')); ?></div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('plans.update')); ?>">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="id" value="<?php echo e($plan->id); ?>">
                            <div class="mb-3">
                                <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($plan->name); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="projects" class="form-label"><?php echo e(__('Projects Allowed')); ?></label>
                                <input type="number" class="form-control" id="projects" name="projects" min="0"  value="<?php echo e($plan->projects); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="tasks_per_project" class="form-label"><?php echo e(__('Tasks per Project')); ?></label>
                                <input type="number" class="form-control" id="tasks_per_project" name="tasks_per_project" value="<?php echo e($plan->tasks_per_project); ?>" min="0" required>
                            </div>

                            <div class="mb-3">
                                <label for="amount" class="form-label"><?php echo e(__('Amount')); ?></label>
                                <input type="number" class="form-control" id="amount" name="amount" min="0" value="<?php echo e($plan->amount); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="duration" class="form-label"><?php echo e(__('Duration (In Days)')); ?></label>
                                <input type="number" class="form-control" id="duration" name="duration" min="0" value="<?php echo e($plan->duration); ?>" required>
                            </div>

                            <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dashboard.wpalleviate.com/resources/views/plans/admin_update.blade.php ENDPATH**/ ?>