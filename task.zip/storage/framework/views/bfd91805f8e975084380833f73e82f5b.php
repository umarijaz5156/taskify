
<title>Pending email verification - <?php echo e($general_settings['company_title']); ?></title>
<?php $__env->startSection('content'); ?>
<!-- Content -->



<div class="container h-100">
    <div class="row align-items-center h-100">
        <div class="col-6 mx-auto">
            <div class="alert alert-danger" role="alert"><?= get_label('pending_email_verification', 'Pending email verification. Please check verification mail sent to you!') ?></div>
            <div class="text-center">
                <a href="/email/verification-notification"><button type="button" class="btn btn-primary"><i class='bx bx-revision'></i> <?= get_label('resend_verification_link', 'Resend verification link') ?></button></a>
            </div>
        </div>
    </div>
</div>

<!-- / Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dashboard.wpalleviate.com/resources/views/auth/verification-notice.blade.php ENDPATH**/ ?>