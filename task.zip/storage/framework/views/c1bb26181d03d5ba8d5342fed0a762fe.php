

<?php $__env->startSection('title'); ?>
<?= get_label('notes', 'Notes') ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between m-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/home')); ?>"><?= get_label('home', 'Home') ?></a>
                    </li>
                    <li class="breadcrumb-item active">
                        <?= get_label('notes', 'Notes') ?>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <span data-bs-toggle="modal" data-bs-target="#create_note_modal">
                <a href="javascript:void(0);" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?= get_label('create_note', 'Create note') ?>">
                    <i class='bx bx-plus'></i>
                </a>
            </span>
        </div>
    </div>

    <div class="card mt-4">

        <?php if($notes->count() > 0): ?>
        <div class="row  mt-4 sticky-notes">
            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 sticky-note">
                <div class="sticky-content sticky-note-bg-<?= $note->color ?>">
                    <div class="text-end">
                        <!-- <span data-bs-toggle="modal" data-bs-target="#create_note_modal"> -->
                        <!-- <span data-bs-toggle="modal" data-bs-target="#create_note_modal"> -->
                            <a href="javascript:void(0);" class="btn btn-primary btn-xs edit-note" data-id='<?php echo e($note->id); ?>' data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?= get_label('update', 'Update') ?>">
                                <i class="bx bx-edit"></i>
                            </a>
                        <!-- </span> -->
                        <a href="javascript:void(0);" class="btn btn-danger btn-xs mx-1 delete" data-id='<?php echo e($note->id); ?>' data-type='notes' data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?= get_label('delete', 'Delete') ?>">
                            <i class="bx bx-trash"></i>
                        </a>
                        <!-- </span> -->
                    </div>
                    <h4><?= $note->title ?></h4>
                    <p><?= $note->description ?></p>
                    <b><?= get_label('created_at', 'Created at') ?> : </b><span class="text-primary"><?php echo e(format_date($note->created_at)); ?></span>
                </div>
            </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <?php
        $type = 'Notes';
        ?>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state-card','data' => ['type' => $type]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('empty-state-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($type)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dashboard.wpalleviate.com/resources/views/notes/list.blade.php ENDPATH**/ ?>