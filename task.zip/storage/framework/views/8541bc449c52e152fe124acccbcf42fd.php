

<?php $__env->startSection('title'); ?>
<?= get_label('task_details', 'Task details') ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="align-items-center d-flex justify-content-between m-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/home')); ?>"><?= get_label('home', 'Home') ?></a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/tasks')); ?>"><?= get_label('tasks', 'Tasks') ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e($task->title); ?></li>
                    <li class="breadcrumb-item active"><?= get_label('view', 'View') ?></li>
                </ol>
            </nav>
        </div>
        <div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">


                <div class="card-body">
                    <div class="d-flex align-items-start align-items-sm-center gap-2">

                        <h2 class="card-header fw-bold"><?php echo e($task->title); ?></h2>
                    </div>
                </div>
                <hr class="my-0" />
                <div class="card-body">


                    <div class="row">

                        <div class="mb-3 col-md-6">

                            <label class="form-label" for="start_date"><?= get_label('users', 'Users') ?></label>
                            <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                <?php
                                $users = $task->users;
                                $clients = $task->project->clients;
                                if (count($users) > 0) { ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li class="avatar avatar-sm pull-up" title="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>"><a href="/users/profile/<?php echo e($user->id); ?>" target="_blank">
                                            <img src="<?php echo e($user->photo ? asset('storage/' . $user->photo) : asset('storage/photos/no-image.jpg')); ?>" class="rounded-circle" alt="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>">
                                        </a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php } else { ?>
                                    <span class="badge bg-primary"><?= get_label('not_assigned', 'Not assigned') ?></span>

                                <?php }
                                ?>
                            </ul>
                        </div>

                        <div class="mb-3 col-md-6">
                            <label class="form-label" for="end_date"><?= get_label('clients', 'Clients') ?></label>
                            <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                <?php
                                if ($clients->count() > 0) { ?>

                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li class="avatar avatar-sm pull-up" title="<?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?>"><a href="/clients/profile/<?php echo e($client->id); ?>" target="_blank">
                                            <img src="<?php echo e($client->photo ? asset('storage/' . $client->photo) : asset('storage/photos/no-image.jpg')); ?>" class="rounded-circle" alt="<?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?>">
                                        </a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php } else { ?>
                                    <span class="badge bg-primary"><?= get_label('not_assigned', 'Not assigned') ?></span>

                                <?php }
                                ?>
                            </ul>
                        </div>
                    </div>

                    <div class="row">

                        <div class="mb-3 col-md-6">
                            <label class="form-label" for="project"><?= get_label('project', 'Project') ?></label>
                            <div class="input-group input-group-merge">
                                <?php
                                $project = $task->project;
                                ?>
                                <input class="form-control px-2" type="text" id="project" placeholder="" value="<?php echo e($project->title); ?>" readonly="">
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="mb-3">
                            <label class="form-label" for="description"><?= get_label('description', 'Description') ?></label>
                            <div class="input-group input-group-merge">
                                <textarea class="form-control" id="description" name="description" rows="5" readonly><?php echo e($task->description); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="mb-3 col-md-6">
                            <label class="form-label" for="start_date"><?= get_label('starts_at', 'Starts at') ?></label>
                            <div class="input-group input-group-merge">
                                <input type="text" name="start_date" class="form-control" placeholder="" value="<?php echo e(format_date($task->start_date)); ?>" readonly />
                            </div>
                        </div>

                        <div class="mb-3 col-md-6">
                            <label class="form-label" for="due-date"><?= get_label('ends_at', 'Ends at') ?></label>
                            <div class="input-group input-group-merge">
                                <input class="form-control" type="text" name="due_date" placeholder="" value="<?php echo e(format_date($task->due_date)); ?>" readonly="">
                            </div>
                        </div>



                        <div class="mb-3 col-md-6">
                            <label class="form-label" for="status"><?= get_label('status', 'Status') ?></label>
                            <div class="input-group input-group-merge">
                                <span class='badge bg-label-<?php echo e($task->status->color); ?> me-1'> <?php echo e($task->status->title); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fastbtce/dasboard.wpalleviate.com/resources/views/tasks/task_information.blade.php ENDPATH**/ ?>