<!-- Footer -->
<div id="section-not-to-print">
<footer class="content-footer footer bg-footer-theme my-4 container-fluid">
    <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0 d-flex align-items-start justify-content-between">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
            ,  <?= $general_settings['footer_text'] ?>
        </div>
    </div>
</footer>
</div>
<!-- / Footer --><?php /**PATH /home2/fastbtce/dasboard.wpalleviate.com/resources/views/components/footer.blade.php ENDPATH**/ ?>