<?php

return [
    'UPDATE_PATH' => 'update/',
    'ALLOW_MODIFICATION' => 1,
];
